Chip's Challenge Retro Remix - by Techokami (Chris Trumbour)

Version: 1.0.3



Changelog:

1.0.3:
-Fixed ordering of Parameceum animations
-Made fireballs only spin counterclockwise
-Curse your eyes, ccexplore! =P

1.0.2:

-Fixed contrast issues with floor tiles

-Chip doesn't bob up and down while walking to the left or right

-Added animated teleport tile, based on the one in the Lynx version

-Went relatively insane from the numerous messages posted by ccexplore on various flaws (that should be all of them!)



1.0.1:

-Added a 32x32 version (atiles2.bmp)



1.0.0:

-IT'S DONE, IT'S FINALLY DONE!

About:
This is a replacement graphics set for Tile World, an open source engine for Chip's Challenge level sets.  It is primarily for Lynx mode (aka, the real deal).
Most of the graphics here are originally from the DOS and Lynx versions of Chip's Challenge.  However, they have been updated to have the same lightning perspective as the more commonplace Microsoft knock-off, as well as color styles.  Some tiles, like the random force floor, exiting chip, and animations for the bomb are all custom-made by Techokami (Chris Trumbour).

Credits:
Paul Vernon - original Chip's Challenge (Lynx) tiles
Art Koch - misc. original Chip's Challenge (Lynx) art
Images Software - graphics from Chip's Challenge (DOS)
Chuck Somerville - Creating the series and help with creating this tileset
ccexplore - Help with creating the tileset and ripping the "poof" animations

Note:
Yes, these tiles are 16x16.  That means the window and gameplay view is going to be very, very small.  (Don't forget that the original Lynx version was on a dinky portable console's screen, and the DOS version only ran at 320x200 resolution in fullscreen mode!)  So, you're going to have to tough it out, unless there is some way to make Tile World increase the image size at runtime... =)

-Chris Trumbour
Jan 27, 2007
