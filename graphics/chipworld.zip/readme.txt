The Chip World graphics were created by Danile Kvarfordt and licensed under the
Creative Commons 3.0 BY license (http://creativecommons.org/licenses/by/3.0/).

The file tiles.bmp was assembled from the Chip World graphics by Andrew Ekstedt
and it is also licensed under the Creative Commons 3.0 BY license.
