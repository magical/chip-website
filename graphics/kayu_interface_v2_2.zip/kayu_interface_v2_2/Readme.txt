To use the bitmap for a specific level set or the original game, follow these instructions:

1. Open Chips.EXE Hacker (aka CCHack -- this program is included in CCTools, which can be found at http://cctools.translucentdragon.com/).

2. Under the "General" Tab, press "Open EXE" and open the executable file which you wish to change (usually it's the original Chip's Challenge).

3. Once it is opened, go to the "Graphics" tab, and "Import" the correct bitmap file to each. The names of the files match (e.g. color tileset, etc.)

4. Under the "General" tab again, press "Write to EXE" and choose the same executable file you opened.

5. If you wish to keep these settings, press "Save Patch."

6. You can now test out the new graphics on your executable file (including your own level set if you wish -- the level set must be using the same source as the executable file which you changed the bitmap for -- these settings can be changed in the "Options" tab in CCManager, which is also included with the CCTools package.).

You can switch back to the original graphics at any time by pressing "Revert" for the graphic attribute under the "Graphics" tab in the open EXE in Chips.EXE Hacker, or by uploading the "Alternate Tileset" to the "Color Tileset" attribute, as well as all of the original files in the same manner (the original files are normally found in the same folder as the original Chip's Challenge). 




For more help visit http://www.freewebs.com/bit_busters/index.htm