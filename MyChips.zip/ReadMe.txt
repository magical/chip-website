MyChips

You should have the following files:

MyChips.exe - a DOS application described in this file
MyChips.c   - C source for MyChips.exe
ReadMe.txt  - what you're reading now


MyChips.exe will allow you to create a "personalized" copy of Chips.exe,
which will access the game-level data from a file you specify, instead
of Chips.dat, and will access score data, etc., from another file you
specify, instead of EntPack.ini.


It will ask you for:

1) the name of the original Chips.exe file - this is where it finds
all the code for the game, etc.

2) the name of your personal copy of Chips.exe - this is the file you
will run when MyChips is finished.

3) the name of your personal copy of EntPack.ini - this is where your
personal copy of Chips.exe will access score data, etc.

4) the name of your personal copy of Chips.dat - this is where your
personal copy of Chips.exe will access game-level data.


You may use this to:

1) play alternate levels - by naming the appropriate Chips.dat file,
and a corresponding EntPack.ini file;

2) protect your hard-earned scores from meddlesome (but well-meaning)
friends, who select "New Game" whenever they start Chips.exe - by
naming "Protect.ini" and "Chips.dat", for instance;

3) anything else that comes to mind.


Limitations:

Your personal copy of Chips.dat must still reside in the same directory
as Chips.exe (your personal copy).  Your personal copy of EntPack.ini
must still reside in the Windows directory.

The maximum length of the filename you choose for your personal copy of
Chips.dat is 9 characters.  The maximum length of the filename you choose
for your personal copy of EntPack.ini is 11 characters.

These limitations are a result of the structure of Chips.exe itself.


If you have recommendations as to how to improve this program, please
feel free to contact the author:

Dale Bryan
<conaire@hotmail.com>