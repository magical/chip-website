#include <stdio.h>
#include <string.h>

#define IniLoc 0x4A68L
#define DatLoc 0x4AD4L
#define IniLen 12
#define DatLen 10
#define ExeLen 13

main()
{
char ExeIn[ExeLen] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
char ExeOut[ExeLen] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
char IniFil[IniLen] = {0,0,0,0,0,0,0,0,0,0,0,0};
char DatFil[DatLen] = {0,0,0,0,0,0,0,0,0,0};
long int i;
int b;
FILE *ExeInF, *ExeOutF;

printf ("Enter name of original Chips.exe file: ");
scanf ("%s",ExeIn);
if ((ExeInF = fopen(ExeIn,"rb")) == NULL)
	{
	printf ("Error opening %s for input\n",ExeIn);
	return (-1);
	}
printf ("Enter name of personal Chips.exe file: ");
scanf ("%s",ExeOut);
if ((ExeOutF = fopen(ExeOut,"wb")) == NULL)
	{
	printf ("Error opening %s for output\n",ExeOut);
	return (-1);
	}
printf ("Enter name of personal Entpack.ini file: ");
scanf ("%s",IniFil);
if (strlen(IniFil) >= IniLen)
	{
	printf ("Maximum length of INI File (11) exceeded");
	return (-1);
	}
printf ("Enter name of personal Chips.dat file: ");
scanf ("%s",DatFil);
if (strlen(DatFil) >= DatLen)
	{
	printf ("Maximum length of DAT File (9) exceeded");
	return (-1);
	}

for (i=0; i<IniLoc; i++)
	{
	b = getc(ExeInF);
	putc (b,ExeOutF);
	}
for (i=0; i<IniLen; i++)
	{
	getc(ExeInF);
	putc (IniFil[i],ExeOutF);
	}
for (i=IniLoc+IniLen; i<DatLoc; i++)
	{
	b = getc(ExeInF);
	putc (b,ExeOutF);
	}
for (i=0; i<DatLen; i++)
	{
	getc(ExeInF);
	putc (DatFil[i],ExeOutF);
	}
while ((b=getc(ExeInF)) != EOF)
	putc (b,ExeOutF);
	
fclose (ExeInF);
fclose (ExeOutF);
printf ("%s complete\n",ExeOut);
return (0);
}